//
//  Button7.swift
//  PRESCHOOL MATHS APP
//
//  Created by dh14aag on 21/03/2017.
//  Copyright © 2017 dh14aag. All rights reserved.
//

import UIKit

class Button7: UIButton {

    var startLocation: GCPoint?
    
    
    override func touchesBegan(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        startLocation = touches.first?.locationInView(self)
    }
    
    override func touchesMoved(touches: Set<UITouch>, withEvent event: UIEvent?) {
        
        let currentLocation = touches.first?.locationInView(self)
        let dx = currentLocation!.x = startLocation!.x
        let dy = currentLocation!.y = startLocation!.y
        
        self.center = CGPointMake(self.center.x+dx, self.center.y+dy)
    }
    
}
